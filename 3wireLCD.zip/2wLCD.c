#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/delay.h>
#include <avr/iom8.h>
#define datapin     0 	// define datapin from atmega8 to 74HC164
#define clockpin    1 	// define clock pin from atmega8 to 74HC164
#define Epin		2	// controllerpin that enables LCD

/*
LCD pins connected to 74hc164:
Q7 ->LCD_D0
Q6 ->LCD_D1
Q5 ->LCD_D2
Q4 ->LCD_D3
Q3 ->LCD_D4
Q2 ->LCD_D5
Q1 ->LCD_D6
Q0 ->LCD_D7
*/
void atmega8init(void)
{
PORTC&=~((1<<datapin)|(1<<clockpin)|(1<<Epin));//set outputs to zerro
DDRC|=(1<<datapin)|(1<<clockpin)|(1<<Epin); //enable output pins
}
void sendByteToRegister(uint8_t LCDdata)
{
uint8_t i, temp;
PORTC&=~_BV(datapin);			// sets datapin to output a LOW
for (i=0;i<=7;i++) 				//clear shift 74HC164 register
	{
		PORTC|=_BV(clockpin);		// sets clockpin to output a HIGH
		_delay_ms(1);
		PORTC&= ~_BV(clockpin);	// sets clockpin to output a LOW
		_delay_ms(1);
	}
temp=LCDdata;	
for (i=0;i<=7;i++)			//write 8bit LCDdata to 74HC164 register
	{
		PORTC |= (LCDdata&1);
		_delay_ms(1);
		PORTC |= _BV(clockpin);		// sets clockpin to output a HIGH
		_delay_ms(1);
		PORTC&= ~_BV(clockpin);	// sets clockpin to output a LOW
		_delay_ms(1);
		PORTC&=~_BV(datapin);	// sets datapin to output a LOW
		_delay_ms(1);
		LCDdata=temp>>1;
		temp=LCDdata;	
	}
}
void enableCommand()
{
PORTC |= _BV(Epin);
}
void disableCommand()
{
PORTC &= ~_BV(Epin);
}
void enableData()
{
PORTC |= _BV(datapin);
PORTC |= _BV(Epin);
}
void disableData()
{
PORTC &= ~_BV(Epin);
PORTC &= ~_BV(datapin);
}
void sendChar(uint8_t letter) //forms data ready to send to 74HC164
{
sendByteToRegister(letter);//sends char to shift register
enableData();
_delay_ms(1);
disableData();
}
void sendCommand(uint8_t cmd) //forms data ready to send to 74HC164
{
sendByteToRegister(cmd);//sends command to shift register
enableCommand();
_delay_ms(1);
disableCommand();
}
void LCDinit(void)
{
_delay_ms(30); //wait for poverup
sendByteToRegister(0x30);//1
enableCommand();
_delay_ms(10);
disableCommand();
sendByteToRegister(0x30);//2
enableCommand();
_delay_ms(10);
disableCommand();
sendByteToRegister(0x30);//3
enableCommand();
_delay_ms(20);
disableCommand();
_delay_ms(10);//wait for more
sendByteToRegister(0x38);//enable 8 bit mode dual line
enableCommand();
_delay_ms(1);
disableCommand();
sendByteToRegister(0x0F);// increment adress counter. Cursor shift
enableCommand();
_delay_ms(1);
disableCommand();
}

int main (void)
{
atmega8init();
LCDinit();
sendChar('T');
sendChar('E');
sendChar('S');
sendChar('T');
sendChar('!');

    /* loop forever, the interrupts are doing the rest */

    for (;;) /* Note [6] */
	{

}
    return (0);
}

